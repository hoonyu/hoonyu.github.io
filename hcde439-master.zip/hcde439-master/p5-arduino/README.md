# p5duino

Examples sketches demonstrating how to make an Arduino talk to p5 over
webserial. Uses the [p5.webserial](https://github.com/gohai/p5.webserial)
library.

In order of increasing complexity:

- button
- plot
- ball
- rgb
- bubbles
- glob
